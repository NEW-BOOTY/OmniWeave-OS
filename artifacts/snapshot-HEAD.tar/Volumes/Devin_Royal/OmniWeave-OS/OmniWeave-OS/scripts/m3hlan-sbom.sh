/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

#!/bin/bash
# M3HLAN tool: m3hlan-sbom
set -euo pipefail
echo "Executing m3hlan-sbom..."
